var viewJson = function(s_width, s_height) {

  var w = 750.00;
  var h = 1134.00;

  var player = new Object();

  /* 歌词页配置 */
  player.lyricView = new LyricView("#FFFFFFFF", "#FFFFFFFF", "#FFFFFFFF", "wood.png");

  player.views = [];

  /* 背景 */
  var bg = new View("view", 0, 0, s_width, s_height, null);
  bg.background = "wood.png";
  player.views.push(bg);


  /* 背景图片 */
  var woodSounder= new Image( 0, 0, 0, 0, bg, "wood_sounder.png");
  woodSounder.x = (48/w) * s_width;
  woodSounder.y = (114/w) * s_height + 16 + 53;
  woodSounder.w = s_width - (96/w)*s_width;
  woodSounder.h = woodSounder.w * (452/631);

  /* 后退按钮 */
  var sideMargin = ( 48 / w) * s_width;
  var backBtn = new Button( sideMargin, 16, 53, 53, bg, "back_normal.png", "back_pressed.png");
  backBtn.action = "back";

  /* 更多按钮 */
  var moreBtn = new Button( 0, backBtn.y, 53, 53, bg, "more_normal.png", "more_pressed.png");
  moreBtn.x = s_width - moreBtn.w - sideMargin;
  moreBtn.action = "more";

  var bottomContainer = new View("view", 0, 0, s_width, s_height, bg);
  bottomContainer.h = (( w - 200)/w) * s_width * (125/552) +  (54 + 48 + 80)*s_height/h + (166/w)*s_width*208/166;
  bottomContainer.y = s_height - bottomContainer.h;
  bottomContainer.background = "#FFFFFFFF";

  /* 更新孔图片的位置 */
  woodSounder.y = (s_height - bottomContainer.h - 53 - 16 - woodSounder.h)/2 + 53 + 16;

  /* 上一首按钮 */
  var preBtn = new Button( 0, 0, 0, 0, bottomContainer, "prev_normal.png", "prev_pressed.png");
  preBtn.x = (100/w)*s_width;
  preBtn.w = (126/w)*s_width;
  preBtn.h = preBtn.w*208/126;
  preBtn.y = bottomContainer.h - (80/h)*s_height - preBtn.h;
  preBtn.action = "playPre";

  /* 下一首按钮 */
  var nextBtn = new Button( 0, 0, 0, 0, bottomContainer, "next_normal.png", "next_pressed.png");
  nextBtn.w = preBtn.w;
  nextBtn.h = preBtn.h;
  nextBtn.y = preBtn.y;
  nextBtn.x = preBtn.x + preBtn.w + 32*s_width/w;
  nextBtn.action = "playNext";


  /*播放暂停按钮 */
  var playPauseBtn = new Button( 0, 0, 0, 0, bottomContainer, "pause_normal.png", "pause_normal.png");
  playPauseBtn.w = (166/w)*s_width;
  playPauseBtn.h = playPauseBtn.w*208/166;
  playPauseBtn.x = s_width - (100/w)*s_width - playPauseBtn.w;
  playPauseBtn.y = bottomContainer.h - (80/h)*s_height - playPauseBtn.h;
  playPauseBtn.action = "playOrPause";
  playPauseBtn.datasource = new PlayButtonDataSource("pause_normal.png", "pause_pressed.png","play_normal.png", "play_pressed.png");

  var lyric_bg = new Image( 0, 0, 0, 0, bottomContainer, "lyric_bg.png");
  
  lyric_bg.x = 100*s_width/w;
  lyric_bg.y = 54*s_height/h;
  lyric_bg.w = s_width - 200*s_width/w;
  lyric_bg.h = lyric_bg.w*125/552;
  
  var progressMargin = (24/w) * s_width;
  var lyricInnerWidth = lyric_bg.w - 2*progressMargin;

  /* 歌曲名 */
  var songLabel = new Label( lyric_bg.x + progressMargin, lyric_bg.y + (55/143)*lyric_bg.h, lyricInnerWidth, lyric_bg.h * 60/160, bottomContainer, 18, "bold", "#FFFFFFFF", "center");
  songLabel.datasource = new DataSongNameLabel();

  /* 单行歌词 */
  var lyric = new OneLineLyric( lyric_bg.x + progressMargin, songLabel.y + songLabel.h, lyricInnerWidth, lyric_bg.h* 45/160, bottomContainer, 14, null, "#FFFFFFFF", "center");
  lyric.datasource = new DataOnelineLyric();

  /* 进度条 */
  var progress = new View("inlineProgress", lyric_bg.x + progressMargin, lyric_bg.y, lyricInnerWidth, lyric_bg.h, bottomContainer);
  progress.datasource = new DataInlineProgress();
  progress.imageThumb = "progress_thumb.png";

  /* hitarea */

  return JSON.stringify(player);
};

var vid = 100; /* view id */
var hitid = 1000; /* hitarea id */
var triggerid = 2000; /* trigger id */

function DataOnelineLyric()
{
  this.type = "onelineLyric";
};

function DataSongNameLabel()
{
  this.type = "songNameLabel";
};

function DataInlineProgress()
{
  this.type = "circleProgress";
};

function DataInlineProgress()
{
  this.type = "inlineProgress";
};

function DataLoveButton(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "loveButton";
  this.buttondata = [];
  var loveBtnData = new ButtonData("love", love_normal_image, love_pressed_image);
  var lovedBtnData = new ButtonData("loved", loved_normal_image, loved_pressed_image);
  this.buttondata.push(loveBtnData, lovedBtnData);
};

function PlayButtonDataSource(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "playButton";
  this.buttondata = [];
  var loveBtnData = new ButtonData("playing", love_normal_image, love_pressed_image);
  var lovedBtnData = new ButtonData("paused", loved_normal_image, loved_pressed_image);
  this.buttondata.push(loveBtnData, lovedBtnData);
};

function ButtonData(name, normal_image, highlight_image)
{
  this.name = name;
  this.normal = normal_image;
  this.highlight = highlight_image;
};

/* Label */
function Label(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "label", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 图片 */
function Image(x, y, w, h, parent_view, image)
{
  View.call(this, "image", x, y, w, h, parent_view);
  this.image = image;
};

/* 按钮 */
function Button(x, y, w, h, parent_view, image, hi_image)
{
  View.call(this, "button", x, y, w, h, parent_view);
  this.image = image;
  this.hi_image = hi_image;
};

/* 单行歌词 */
function OneLineLyric(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "oneLineLyric", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 歌词页 */
function LyricView(lyricColor, lyricTranslateColor, lyricHighlightColor, background)
{
  this.lyricColor = lyricColor;
  this.lyricTranslateColor = lyricTranslateColor;
  this.lyricHighlightColor = lyricHighlightColor;
  this.background = background;
};

function View(type, x, y, w, h, parent_view)
{
  this.id = vid++;
  this.type = type;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.views = [];
  if (parent_view != null) {
    parent_view.views.push(this);
  }

/* hitarea */
function Hitarea(x, y, w, h, gestures, triggers)
{
  this.id = hitarea++;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.gestures = gestures;
  this.triggers = triggers;
};

/* trigger */
function Trigger(action)
{
  this.id = triggerid++;
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

};
