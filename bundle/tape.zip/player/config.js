var viewJson = function(s_width, s_height) {

  var player = new Object();

  /* 歌词页配置 */
  player.lyricView = new LyricView("#FFFFFFFF", "#FFFFFFFF", "#FFFFFFFF", "top #C0F9F8FF #9CD8D7FF");

  player.views = [];

  /* 通用距离 */
  var sideMargin = (86 / 750) * s_width;

  /* 背景 */
  var bg = new View("view", 0, 0, s_width, s_height, null);
  bg.background = "#F3F3F2FF";
  player.views.push(bg);

  /* 后退按钮 */
  var sideMargin = 0.064 * s_width;
  var backBtn = new Button( sideMargin, 20, 53, 40, bg, "back_normal.png", "back_pressed.png");
  backBtn.action = "back";

  /* 更多按钮 */
  var moreBtn = new Button( 0, backBtn.y, 53, 40, bg, "more_normal.png", "more_pressed.png");
  moreBtn.x = s_width - moreBtn.w - sideMargin;
  moreBtn.action = "more";

  /* 磁带区域 */
  var tapeScale = s_width / 750;
  var tapeContainer = new View("view", 0, moreBtn.y + moreBtn.h, s_width, 500 * tapeScale, bg);
  tapeContainer.background = "#5B564FFF";
  /* 左边轮子 */
  var leftWheel = new Image(0, 0, 500*tapeScale, 500*tapeScale, tapeContainer, "left_wheel.png");
  leftWheel.x = 0 - (250 - 128) * tapeScale;
  /* 右边轮子 */
  var rightWheel = new Image(0, 0, 500*tapeScale, 500*tapeScale, tapeContainer, "right_wheel.png");
  rightWheel.x = tapeContainer.w - rightWheel.w + (250 - 128) * tapeScale;
  /* 磁带蒙版 */
  var tapeMask = new Image(0, 0, tapeContainer.w, tapeContainer.h, tapeContainer, "mask.png");

  /* 磁带转动动画 */
  player.animations = [];
  var leftSpin = new SpinAnimation(leftWheel.id, 10, 0, "play");
  var rightSpin = new SpinAnimation(rightWheel.id, 10, 0, "play");
  player.animations.push(leftSpin, rightSpin);

  /* 歌曲名 */
  var songLabel = new Label(sideMargin, 0, s_width - 2*sideMargin, 37, bg, 21, "bold", "#585858FF", "center");
  songLabel.y = tapeContainer.y + tapeContainer.h- songLabel.h;
  songLabel.datasource = new DataSongNameLabel();

  /* 歌手名 */
  var singerLabel = new Label(sideMargin, 0, s_width - 2*sideMargin, 24, bg, 18, null, "#585858FF", "center");
  singerLabel.y = songLabel.y + songLabel.h;
  singerLabel.datasource = new DataSingerNameLabel();

  /* 下方操作按钮 */
  var downBtns = new View("view", 0, 0, 0.77*s_width, 0, bg);
  downBtns.h = downBtns.w * (110 / 571);
  downBtns.x = (s_width - downBtns.w)/2
  downBtns.y = s_height - downBtns.h - (78/1134) * s_height;

  var rightBtnBg = new Image( 0, 0, downBtns.w, downBtns.h, downBtns, "btn_bg.png");

  var rBtnW = (downBtns.w) / 5 + 1;
  var rBtnH = rBtnW * (111 / 115);

  /* 收藏按钮 */
  var loveBtn = new Button( 0, 0, rBtnW, rBtnH, downBtns, "love_normal.png", "love_pressed.png");
  loveBtn.action = "love";
  loveBtn.datasource = new DataLoveButton("love_normal.png", "love_pressed.png", "loved_normal.png", "loved_pressed.png");
  /* 上一首按钮 */
  var preBtn = new Button( loveBtn.x + rBtnW - 1, 0, rBtnW, rBtnH, downBtns, "pre_normal.png", "pre_pressed.png");
  preBtn.action = "playPre";
  /* 播放按钮 */
  var playBtn = new Button ( preBtn.x + rBtnW - 1, 0, rBtnW, rBtnH, downBtns, "play_normal.png", "play_pressed.png");
  playBtn.action = "playOrPause";
  /* 下一首按钮 */
  var nextBtn = new Button( playBtn.x + rBtnW - 1, 0, rBtnW, rBtnH, downBtns, "next_normal.png", "next_pressed.png");
  nextBtn.action = "playNext";
  /* 分享按钮 */
  var shareBtn = new Button( nextBtn.x + rBtnW - 1, 0, rBtnW, rBtnH, downBtns, "share_normal.png", "share_pressed.png");
  shareBtn.action = "share";

  /* 进度条 */
  var progressMargin = (24/750) * s_width;
  var progress = new View("inlineProgress", 0, 0, (576/750) * s_width, 0, bg);
  progress.h = (80/576) * progress.w;
  progress.x = (s_width - progress.w) / 2;
  progress.y = downBtns.y - (58/1134) * s_height - progress.h;
  progress.datasource = new DataInlineProgress();
  progress.imageThumb = "thumb.png";
  progress.imageLeft = "progress_left.png";
  progress.imageRight = "progress_right.png";
  progress.imageCapLeft = (7/576) * progress.w;
  progress.imageCapRight = (7/576) * progress.w;

  /* 歌词区域 */
  var lyric = new MultilineLyric(0, 0, 0, 0, bg, 14, null, "#585655FF", "center")
  lyric.w = s_width;
  lyric.y = singerLabel.y + singerLabel.h + 10;
  lyric.h = progress.y - lyric.y - 10;
  lyric.datasource = new DataOnelineLyric();

  return JSON.stringify(player);
};

var vid = 100; /* view id */

function DataOnelineLyric()
{
  this.type = "onelineLyric";
};

function DataOnelineLyric()
{
  this.type = "multilineLyric";
};

function DataSingerNameLabel()
{
  this.type = "singerNameLabel";
};

function DataSongNameLabel()
{
  this.type = "songNameLabel";
};

function DataInlineProgress()
{
  this.type = "circleProgress";
};

function DataInlineProgress()
{
  this.type = "inlineProgress";
};

function DataLoveButton(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "loveButton";
  this.buttondata = [];
  var loveBtnData = new ButtonData("love", love_normal_image, love_pressed_image);
  var lovedBtnData = new ButtonData("loved", loved_normal_image, loved_pressed_image);
  this.buttondata.push(loveBtnData, lovedBtnData);
};

function ButtonData(name, normal_image, highlight_image)
{
  this.name = name;
  this.normal = normal_image;
  this.highlight = highlight_image;
};

/* Label */
function Label(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "label", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 图片 */
function Image(x, y, w, h, parent_view, image)
{
  View.call(this, "image", x, y, w, h, parent_view);
  this.image = image;
};

/* 按钮 */
function Button(x, y, w, h, parent_view, image, hi_image)
{
  View.call(this, "button", x, y, w, h, parent_view);
  this.image = image;
  this.hi_image = hi_image;
};

/* 单行歌词 */
function OneLineLyric(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "oneLineLyric", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 歌词页 */
function MultilineLyric(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "multilineLyric", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 歌词页 */
function LyricView(lyricColor, lyricTranslateColor, lyricHighlightColor, background)
{
  this.lyricColor = lyricColor;
  this.lyricTranslateColor = lyricTranslateColor;
  this.lyricHighlightColor = lyricHighlightColor;
  this.background = background;
};

function View(type, x, y, w, h, parent_view)
{
  this.id = vid++;
  this.type = type;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.views = [];
  if (parent_view != null) {
    parent_view.views.push(this);
  }
};

var animation_id = 3000;
function Animation(type, viewId, duration, repeat, playOnState)
{
  this.id = animation_id++;
  this.viewId = viewId;
  this.type = type;
  this.duration = duration;
  this.repeat = repeat;
  this.playOnState = playOnState;
}

function SpinAnimation(viewId, duration, repeat, playOnState)
{
  Animation.call(this, "spin", viewId, duration, repeat, playOnState);
}
