
// 以下代码仅供测试页面使用


document.addEventListener('DOMContentLoaded', function() {
  //alert("READY!");
  reloadViews();
}, false);

function reloadViews()
{
  var w = document.getElementById("s_width").value;
  var h = document.getElementById("s_height").value;
  var json = viewJson(w, h)

  document.getElementById("debug_container").innerHTML = "";
  document.getElementById("demo").innerHTML = "";
  document.getElementById("demo").innerHTML = json;
  createUI(json);
}

function getRandomColor() {
  var letters = '0123456789ABCDEF'.split('');
  var color = '#';
  for (var i = 0; i < 6; i++ ) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

function createAreaItem(id,x, y, w, h){
  var divItem = document.createElement("div");
  divItem.style.position = "absolute";
  divItem.style.backgroundColor = "#000000";
  divItem.style.opacity = 0.2;
  
  divItem.id = id;
  divItem.style.left =  x + "px";
  divItem.style.top =  y + "px";
  divItem.style.width =  w + "px";
  divItem.style.height =  h + "px";
   
  return divItem;
}

function createDivItem(view){
  var id = view["id"];
  var img = view["image"];
  var x = view["x"];
  var y = view["y"];
  var w = view["w"];
  var h = view["h"];
  var type = view["type"];

  var divItem = document.createElement("div");
  divItem.style.position = "absolute";
  if (img != undefined)
  {
    divItem.style.backgroundImage = "url('./images/" + img + "')";
    divItem.style.backgroundSize = "contain";
  }
  else
  {
    divItem.style.backgroundColor = getRandomColor();
  }
  
  divItem.id = id;
  divItem.style.left =  x + "px";
  divItem.style.top =  y + "px";
  divItem.style.width =  w + "px";
  divItem.style.height =  h + "px";
  //divItem.style.opacity = 0.7;

  var isknownView = (type == "view" || type == "image" || type == "button");
  if (isknownView == false) {
    divItem.innerHTML = type;
  }
  //divItem.style.borderColor = getRandomColor();
  //divItem.style.borderWidth = "thick";
   
  return divItem;
}

function createView(rootView){
  var divItem = createDivItem(rootView);
  
  var subViews = rootView["views"];
  for (var view in subViews){
    var innerDivItem = createView(subViews[view]);
    divItem.appendChild(innerDivItem);
    console.log(divItem);
  }
  return divItem;
}

function createHitarea(hitarea){
  for (var i =0; i < hitarea.length; i++) {
    var area = hitarea[i];
    var targetView = document.getElementById(area["viewId"]);
    var divItem = createAreaItem(area["id"], area["x"], area["y"], area["w"], area["h"]);
    targetView.appendChild(divItem);
    var hint = document.getElementById('hint');
    hint.innerHTML = JSON.stringify(area);
    divItem.onmouseover = function() {
        hint.style.display = 'block';
    }
    divItem.onmouseout = function() {
        hint.style.display = 'none';
    }

    console.log(divItem);
  }
}

function createUI(uiControls){
  var player = JSON.parse(uiControls);
  
  var overview = createView(player["views"][0]);
  console.log(overview.style);
  //document.body.appendChild(overview);
  var container = document.getElementById("debug_container");
  container.style.position = "relative";
  container.appendChild(overview);

  createHitarea(player["hitarea"]);
}
