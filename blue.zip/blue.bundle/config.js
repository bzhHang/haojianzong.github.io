var viewJson = function(s_width, s_height) {

  var player = new Object();

  /* 歌词页配置 */
  player.lyricView = new LyricView("#FFFFFFFF", "#FFFFFFFF", "#FFFFFFFF");

  player.views = [];

  /* 背景 */
  var bg = new View("view", 0, 0, s_width, s_height, null);
  bg.background = "top #C0F9F8FF #9CD8D7FF";
  player.views.push(bg);

  /* 后退按钮 */
  var sideMargin = 0.064 * s_width;
  var backBtn = new Button( sideMargin, 20, 44, 44, bg, "back_normal.png", "back_pressed.png");
  backBtn.action = "back";

  /* 更多按钮 */
  var moreBtn = new Button( 0, backBtn.y, 44, 44, bg, "more_normal.png", "more_pressed.png");
  moreBtn.x = s_width - moreBtn.w - sideMargin;
  moreBtn.action = "more";

  /* 下方操作按钮 */
  var rightBtns = new View("view", 0, 0, 0.63*s_width, 0, bg);
  rightBtns.h = rightBtns.w * (120 / 472);
  rightBtns.x = s_width - rightBtns.w - 0.08 * s_width;
  rightBtns.y = s_height - rightBtns.h - 0.074 * s_width;

  var rightBtnBg = new Image( 0, 0, rightBtns.w, rightBtns.h, rightBtns, "btn_bg.png");

  var rBtnW = (rightBtns.w - 8) / 4;
  var rBtnH = rBtnW * (60 / 57);
  /* 上一首按钮 */
  var preBtn = new Button( 1, 0, rBtnW, rBtnH, rightBtns, "pre_normal.png", "pre_pressed.png");
  preBtn.action = "playPre";
  /* 下一首按钮 */
  var nextBtn = new Button( preBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "next_normal.png", "next_pressed.png");
  nextBtn.action = "playNext";
  /* 收藏按钮 */
  var loveBtn = new Button( nextBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "love_normal.png", "love_pressed.png");
  loveBtn.action = "love";
  loveBtn.datasource = new DataLoveButton("love_normal.png", "love_pressed.png", "loved_normal.png", "loved_pressed.png");
  /* 分享按钮 */
  var shareBtn = new Button( loveBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "share_normal.png", "share_pressed.png");
  shareBtn.action = "share";

  /* 播放按钮 */
  var playBtn = new Button (0.08 * s_width, rightBtns.y, rBtnW, rBtnH, bg, "play_normal.png", "play_pressed.png");
  playBtn.action = "playOrPause";

  /* 歌词区域 */
  var lyric_margin = (30 / 750) * s_width;
  var lyricContainer = new View("view", lyric_margin, 0, 0, 0, bg);
  lyricContainer.w = s_width - 2*lyric_margin;
  lyricContainer.h = (143/625) * lyricContainer.w;
  lyricContainer.y = rightBtns.y - 0.05 * s_height - lyricContainer.h;

  var lyric_bg = new Image( 0, 0, lyricContainer.w, lyricContainer.h, lyricContainer, "lyric_bg.png");

  /* 进度条 */
  var progressMargin = (24/750) * s_width;
  var progress = new View("inlineProgress", progressMargin, 0, lyricContainer.w - 2*progressMargin, lyricContainer.h, lyricContainer);
  progress.datasource = new DataInlineProgress();
  progress.imageThumb = "progress_thumb.png";

  /* 歌曲名 */
  var songLabel = new Label(progressMargin, (30/160) * lyricContainer.h, progress.w,(42/160) * lyricContainer.h,lyricContainer, 14, "bold", "#FFFFFFFF", "center");
  songLabel.datasource = new DataSongNameLabel();

  /* 单行歌词 */
  var lyric = new OneLineLyric(progressMargin, songLabel.y + songLabel.h, progress.w,(34/160) * lyricContainer.h, lyricContainer, 14, null, "#FFFFFFFF", "center");
  lyric.datasource = new DataOnelineLyric();

  /* 中间的音响 */
  var hifi = new Image( 0, backBtn.y + backBtn.h + (32/1134)*s_height, 0, 0, bg, "hifi.png");
  hifi.h = lyricContainer.y - hifi.y - 0.1 * s_height;
  hifi.w = hifi.h;
  hifi.x = (s_width - hifi.w) / 2;

  return JSON.stringify(player);
};

var vid = 100; /* view id */

function DataOnelineLyric()
{
  this.type = "onelineLyric";
};

function DataSongNameLabel()
{
  this.type = "songNameLabel";
};

function DataInlineProgress()
{
  this.type = "circleProgress";
};

function DataInlineProgress()
{
  this.type = "inlineProgress";
};

function DataLoveButton(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "loveButton";
  this.love = love_normal_image + "," + love_pressed_image;
  this.loved = loved_normal_image + "," + loved_pressed_image;
};

/* Label */
function Label(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "label", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 图片 */
function Image(x, y, w, h, parent_view, image)
{
  View.call(this, "image", x, y, w, h, parent_view);
  this.image = image;
};

/* 按钮 */
function Button(x, y, w, h, parent_view, image, hi_image)
{
  View.call(this, "button", x, y, w, h, parent_view);
  this.image = image;
  this.hi_image = hi_image;
};

/* 单行歌词 */
function OneLineLyric(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "OneLineLyric", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 歌词页 */
function LyricView(lyricColor, lyricTranslateColor, lyricHighlightColor)
{
  this.lyricColor = lyricColor;
  this.lyricTranslateColor = lyricTranslateColor;
  this.lyricHighlightColor = lyricHighlightColor;
};

function View(type, x, y, w, h, parent_view)
{
  this.id = vid++;
  this.type = type;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.views = [];
  if (parent_view != null) {
    parent_view.views.push(this);
  }
};
