var viewJson = function(s_width, s_height) {

  var player = new Object();
  player.views = [];

  // 背景
  var bg = new View("view", 0, 0, s_width, s_height, null);
  bg.color = "C0F9F8";
  player.views.push(bg);

  /*
  var backBtn = new view("button", "24", "40", "44", "44", bg);
  backBtn.image = "back_normal.png";
  */

  // 后退按钮
  var sideMargin = 24;
  var backBtn = new Button( sideMargin, 20, 44, 44, bg, "back_normal.png", "back_pressed.png");
  backBtn.action = "back";

  // 更多按钮
  var moreBtn = new Button( 0, backBtn.y, 44, 44, bg, "more_normal.png", "more_pressed.png");
  moreBtn.x = s_width - moreBtn.w - sideMargin;
  moreBtn.action = "more";

  // 中间的音响
  var hifiMargin = 21;
  var hifi = new Image( hifiMargin, backBtn.y + backBtn.h + 16, 0, 333, bg, "hifi.png");
  hifi.w = s_width - 2*hifiMargin;
  hifi.h = hifi.w;

  // 歌词区域
  var lyric_margin = 30;
  var lyricContainer = new View("view", lyric_margin, hifi.y + hifi.h + 64, 0, 72, bg);
  lyricContainer.w = s_width - 2*lyric_margin;

  var lyric_bg = new Image( 0, 0, lyricContainer.w, lyricContainer.h, lyricContainer, "lyric_bg.png");

  // 进度条
  var progress = new View("inlineProgress", 0, 0, lyricContainer.w, lyricContainer.h, lyricContainer);
  progress.datasource = new DataProgress();
  progress.imageThumb = "progress_thumb.png";

  // 下方操作按钮
  var rightBtns = new View("view", 0, 0, 236, 60, bg);
  rightBtns.x = s_width - rightBtns.w - 30;
  rightBtns.y = s_height - rightBtns.h - 36;
  var rightBtnBg = new Image( 0, 0, rightBtns.w, rightBtns.h, rightBtns, "btn_bg.png");

  var rBtnW = 57;
  var rBtnH = 60;
  // 上一首按钮
  var preBtn = new Button( 1, 0, rBtnW, rBtnH, rightBtns, "pre_normal.png", "pre_pressed.png");
  preBtn.action = "playPre";
  // 下一首按钮
  var nextBtn = new Button( preBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "next_normal.png", "next_pressed.png");
  nextBtn.action = "playNext";
  // 收藏按钮
  var loveBtn = new Button( nextBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "love_normal.png", "love_pressed.png");
  loveBtn.action = "love";
  loveBtn.datasource = new DataLoveButton("love_normal.png", "love_pressed.png", "loved_normal.png", "loved_pressed.png");
  // 分享按钮
  var shareBtn = new Button( loveBtn.x + rBtnW + 2, 0, rBtnW, rBtnH, rightBtns, "share_normal.png", "share_pressed.png");
  shareBtn.action = "share";

  return JSON.stringify(player);
}

var vid = 100; // view id

function DataProgress()
{
  this.type = "progressBar";
}

function DataLoveButton(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "loveButton";
  this.love = love_normal_image + "," + love_pressed_image;
  this.loved = loved_normal_image + "," + loved_pressed_image;
}

// 图片
function Image(x, y, w, h, parent_view, image)
{
  View.call(this, "image", x, y, w, h, parent_view);
  this.image = image;
}

// 按钮
function Button(x, y, w, h, parent_view, image, hi_image)
{
  View.call(this, "button", x, y, w, h, parent_view);
  this.image = image;
  this.hi_image = hi_image;
}

function View(type, x, y, w, h, parent_view)
{
  this.id = vid++;
  this.type = type;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.views = [];
  if (parent_view != null) {
    parent_view.views.push(this);
  }
}

// 以下代码仅供测试页面使用


document.addEventListener('DOMContentLoaded', function() {
  //alert("READY!");
  reloadViews();
}, false);

function reloadViews()
{
  var w = document.getElementById("s_width").value;
  var h = document.getElementById("s_height").value;
  var json = viewJson(w, h)

  document.getElementById("debug_container").innerHTML = "";
  document.getElementById("demo").innerHTML = "";
  document.getElementById("demo").innerHTML = json;
  createUI(json);
}
