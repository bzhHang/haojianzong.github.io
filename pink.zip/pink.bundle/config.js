var viewJson = function(s_width, s_height) {

  var player = new Object();

  /* 歌词页配置 */
  player.lyricView = new LyricView("top #C5DFCE #758A7DFF", "#FFFFFFFF", "top #C5DFCEFF #AECFBAFF");

  player.views = [];
  
  var topY = 0;
  var bottomY = s_height;
  var scaleX = s_width / 750;
  var scaleY = s_height / 1334;

  /* 背景 */
  var bg = new View("view", 0, 0, s_width, s_height, null);
  bg.background = "top #C5DFCE #AECFBA";
  player.views.push(bg);

  topY = 20;
  /* 后退按钮 */
  var sideMargin = 0.064 * s_width;
  var backBtn = new Button( sideMargin, topY, 44, 44, bg, "back_normal.png", "back_pressed.png");
  backBtn.action = "back";

  /* 更多按钮 */
  var moreBtn = new Button( 0, topY, 44, 44, bg, "more_normal.png", "more_pressed.png");
  moreBtn.x = s_width - moreBtn.w - sideMargin;
  moreBtn.action = "more";

  topY = moreBtn.y + moreBtn.h + 22 * scaleY;
  bottomY = 108 * scaleY;
  /* 底部操作按钮 */
  var playBtnsW = s_width;
  var playBtns = new View("view", 0, 0, playBtnsW, 0, bg);
  playBtns.h = 326 * scaleX;
  playBtns.y = s_height - playBtns.h - bottomY;
  
  var playBtnsBg = new Image( 0, 0, playBtns.w, playBtns.h, playBtns, "btn_bg.png");

  var horizonMarginPadding = 70 * scaleX;
  var btnPadding = 25 * scaleX;
  var playSmallBtnW = 161 * scaleX;
  var playBigBtnW = 238 * scaleX;
  /* 上一首按钮 */
  var preBtn = new Button( horizonMarginPadding, 0, playSmallBtnW, playBtns.h, playBtns, "pre_normal.png", "pre_pressed.png");
  preBtn.action = "playPre";
  /* 播放按钮 */
  var playBtn = new Button (preBtn.x + preBtn.w + btnPadding, 0, playBigBtnW, playBtns.h, playBtns, "play_normal.png", "play_pressed.png");
  playBtn.action = "playOrPause";
  /* 下一首按钮 */
  var nextBtn = new Button( playBtn.x + playBtn.w + btnPadding, 0, playSmallBtnW, playBtns.h, playBtns, "next_normal.png", "next_pressed.png");
  nextBtn.action = "playNext";

  bottomY = playBtns.y - 20 * scaleY;
  /* 歌词区域 */
  var lyricW = 585 * scaleX;
  var lyricH = 294 * scaleX;
  var lyricContainer = new View("view", (s_width - lyricW) / 2, bottomY - lyricH, lyricW, lyricH, bg);

  var lyric_bg = new Image( 0, 0, lyricContainer.w, lyricContainer.h, lyricContainer, "lyric_bg.png");
  var lyric_bg_highlight = new Image( 0, 0, lyricContainer.w, lyricContainer.h, lyricContainer, "lyric_bg_highlight.png");

  /* 歌曲名 */
  var progressMargin = 80 * scaleX;
  var lyricInnerWidth = lyricContainer.w - 2 * progressMargin;
  var songLabel = new Label(progressMargin,60 * scaleX, lyricInnerWidth, 60 * scaleX, lyricContainer, 18, "bold", "#758A7DFF", "center");
  songLabel.datasource = new DataSongNameLabel();
  
  /* 单行歌词 */
  var lyric = new OneLineLyric(progressMargin, songLabel.y + songLabel.h, lyricInnerWidth, 60 * scaleX, lyricContainer, 14, null, "#758A7DFF", "center");
  lyric.datasource = new DataOnelineLyric();

  /* 进度条 */
  var progress = new View("inlineProgress", progressMargin, lyric.y + lyric.h + 30 * scaleX, lyricInnerWidth, 12 * scaleX, lyricContainer);
  progress.datasource = new DataInlineProgress();
  progress.imageLeft = "progress_left.png";
  progress.imageLeft = "progress_right.png";
  progress.imageCapLeft = 6 * scaleX
  progress.imageCapRight = 6 * scaleX;


  bottomY = lyricContainer.y - 30 * scaleY;
  /* 中间的音响 */
  var hifi_h = bottomY - topY;
  var hifi_w = (750 / 406) * hifi_h;
  var hifi = new Image( (s_width - hifi_w) / 2, topY, hifi_w, hifi_h, bg, "hifi.png");

  /* hitarea */

  return JSON.stringify(player);
};

var vid = 100; /* view id */
var hitid = 1000; /* hitarea id */
var triggerid = 2000; /* trigger id */

function DataOnelineLyric()
{
  this.type = "onelineLyric";
};

function DataSongNameLabel()
{
  this.type = "songNameLabel";
};

function DataInlineProgress()
{
  this.type = "circleProgress";
};

function DataInlineProgress()
{
  this.type = "inlineProgress";
};

function DataLoveButton(love_normal_image, love_pressed_image, loved_normal_image, loved_pressed_image)
{
  this.type = "loveButton";
  this.buttondata = [];
  var loveBtnData = new ButtonData("love", love_normal_image, love_pressed_image);
  var lovedBtnData = new ButtonData("loved", loved_normal_image, loved_pressed_image);
  this.buttondata.push(loveBtnData, lovedBtnData);
};

function ButtonData(name, normal_image, highlight_image)
{
  this.name = name;
  this.normal = normal_image;
  this.highlight = highlight_image;
};

/* Label */
function Label(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "label", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 图片 */
function Image(x, y, w, h, parent_view, image)
{
  View.call(this, "image", x, y, w, h, parent_view);
  this.image = image;
};

/* 按钮 */
function Button(x, y, w, h, parent_view, image, hi_image)
{
  View.call(this, "button", x, y, w, h, parent_view);
  this.image = image;
  this.hi_image = hi_image;
};

/* 单行歌词 */
function OneLineLyric(x, y, w, h, parent_view, size, weight, color, textAlignment)
{
  View.call(this, "oneLineLyric", x, y, w, h, parent_view);
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

/* 歌词页 */
function LyricView(lyricColor, lyricHighlightColor, background)
{
  this.lyricColor = lyricColor;
  this.lyricHighlightColor = lyricHighlightColor;
  this.background = background;
};

function View(type, x, y, w, h, parent_view)
{
  this.id = vid++;
  this.type = type;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.views = [];
  if (parent_view != null) {
    parent_view.views.push(this);
  }

/* hitarea */
function Hitarea(x, y, w, h, gestures, triggers)
{
  this.id = hitarea++;
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.gestures = gestures;
  this.triggers = triggers;
};

/* trigger */
function Trigger(action)
{
  this.id = triggerid++;
  this.fontSize = size;
  this.fontWeight = weight;
  this.fontColor = color;
  this.textAlignment = textAlignment;
};

};
