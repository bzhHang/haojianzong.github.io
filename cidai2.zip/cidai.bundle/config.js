var viewJson = function(s_width, s_height) {
  var player = new Object();
  var common_id = 500;

  player.views = [];

  // 背景，可以用背景图、或者自定义颜色
  var background = new Object();
  background.id = common_id++;
  background.type = "view";
  background.x = "0.0";
  background.y = "0.0";
  background.w = s_width;
  background.h = s_height;
  background.color = "F3F3F2";
  background.views = [];

  player.views.push(background);

  // 返回按钮，绝对定位，绝对大小，放在左上角
  var backBtn = new Object();
  backBtn.id = 111;
  backBtn.type = "button";
  backBtn.x = 20;
  backBtn.y = 20;
  backBtn.w = 53;
  backBtn.h = 38;
  backBtn.image = "cidai_back.png";
  background.views.push(backBtn);

  // 更多按钮，绝对定位，放在右上角
  var moreBtn = new Object();
  moreBtn.id = 112;
  moreBtn.type = "button";
  moreBtn.w = 53;
  moreBtn.h = 38;
  moreBtn.x = s_width - moreBtn.w - 20;
  moreBtn.y = 20;
  moreBtn.image = "cidai_more.png";
  background.views.push(moreBtn);

  // 歌名Label
  var lyricLabel = new Object();
  lyricLabel.id = 116;
  lyricLabel.type = "label";
  lyricLabel.w = 200;
  lyricLabel.h = 38;
  lyricLabel.x = (s_width - lyricLabel.w)/2;
  lyricLabel.y = 20;
  background.views.push(lyricLabel);

  // 磁带容器
  var cidai = new Object();
  cidai.id = common_id++;
  cidai.type = "view";
  cidai.x = "0.0";
  cidai.y = 140;
  cidai.w = s_width;
  cidai.h = 70;
  cidai.views = [];
  background.views.push(cidai);

  // 磁带中心图片
  var c_center = new Object();
  c_center.id = common_id++;
  c_center.type = "image";
  c_center.w = 150;
  c_center.h = 55;
  c_center.x = cidai.w/2 - c_center.w/2;
  c_center.y = 0;
  c_center.image = "cidai_center.png";
  cidai.views.push(c_center);

  // 磁带左边圈圈，动画转起来
  var c_left = new Object();
  c_left.id = common_id++;
  c_left.type = "image";
  c_left.w = 74;
  c_left.h = 74;
  c_left.x = c_center.x - 20 - c_left.w;
  c_left.y = c_center.y + c_center.h/2 - c_left.h/2;
  c_left.image = "cidai_hole.png";
  c_left.animation = "rotation";
  cidai.views.push(c_left);

  // 磁带右边圈圈，动画转起来
  var c_right = new Object();
  c_right.id = common_id++;
  c_right.type = "image";
  c_right.w = 74;
  c_right.h = 74;
  c_right.x = c_center.x + c_center.w + 20;
  c_right.y = c_left.y;
  c_right.animation = "rotation";
  c_right.image = "cidai_hole.png";
  cidai.views.push(c_right);

  // 歌词控件
  var lyricView = new Object();
  lyricView.id = 113;
  lyricView.type = "image";
  lyricView.w = 224;
  lyricView.h = 213;
  lyricView.x = s_width/2 - lyricView.w/2;
  lyricView.y = cidai.y + cidai.h + 30;
  lyricView.image = "cidai_lyric.png";
  background.views.push(lyricView);

  // 控制按钮，与屏幕下方对齐
  // 按钮容器
  var btnW = 58;
  var btnH = 56;
  var btnCount = 5;
  var btnI = 0;

  var controls = new Object();
  controls.id = common_id++;
  controls.type = "view";
  controls.w = btnW * btnCount;
  controls.h = btnH;
  controls.x = s_width/2 - controls.w/2;
  controls.y = s_height - btnH - 20;
  controls.color = "#888888";
  controls.views = [];
  background.views.push(controls);

  // 喜欢
  var likeBtn = new Object();
  likeBtn.id = 106;
  likeBtn.type = "button";
  likeBtn.w = btnW;
  likeBtn.h = btnH;
  likeBtn.x = btnI * btnW;
  likeBtn.y = 0;
  likeBtn.image = "cidai_love.png";
  controls.views.push(likeBtn);
  btnI++;

  // 上一首
  var preBtn = new Object();
  preBtn.id = 103;
  preBtn.type = "button";
  preBtn.w = btnW;
  preBtn.h = btnH;
  preBtn.x = btnI * btnW;
  preBtn.y = 0;
  preBtn.image = "cidai_pre.png";
  controls.views.push(preBtn);
  btnI++;

  // 播放
  var playBtn = new Object();
  playBtn.id = 101;
  playBtn.type = "button";
  playBtn.w = btnW;
  playBtn.h = btnH;
  playBtn.x = btnI * btnW;
  playBtn.y = 0;
  playBtn.image = "cidai_play.png";
  controls.views.push(playBtn);
  btnI++;

  // 下一首
  var nextBtn = new Object();
  nextBtn.id = 104;
  nextBtn.type = "button";
  nextBtn.w = btnW;
  nextBtn.h = btnH;
  nextBtn.x = btnI * btnW;
  nextBtn.y = 0;
  nextBtn.image = "cidai_next.png";
  controls.views.push(nextBtn);
  btnI++;

  // 分享
  var shareBtn = new Object();
  shareBtn.id = 105;
  shareBtn.type = "button";
  shareBtn.w = btnW;
  shareBtn.h = btnH;
  shareBtn.x = btnI * btnW;
  shareBtn.y = 0;
  shareBtn.image = "cidai_share.png";
  controls.views.push(shareBtn);
  btnI++;

  /*
  // 进度条
  var progressView = new Object();
  progressView.id = 108;
  progressView.type = "inlineProgress";
  progressView.w = 345;
  progressView.h = 23;
  progressView.x = s_width/2 - progressView.w/2;
  progressView.y = controls.y - progressView.h - 20;
  progressView.datasource = "progressBar";
  progressView.imageLeft = "progress_left.png";
  progressView.imageRight = "progress_right.png";
  progressView.imageLoad = "progress_load.png";
  progressView.imageThumb = "progress_thumb.png";
  background.views.push(progressView);
  */

  // 进度条背景
  var proContainer = new Object();
  proContainer.id = common_id++;
  proContainer.views = [];
  proContainer.type = "view";
  proContainer.w = 333;
  proContainer.h = 80;
  proContainer.x = s_width/2 - proContainer.w/2;
  proContainer.y = controls.y - proContainer.h - 20;
  background.views.push(proContainer);
  
  var proBg = new Object();
  proBg.id = common_id++;
  proBg.x = 0;
  proBg.y = 0;
  proBg.w = proContainer.w;
  proBg.h = proContainer.h;
  proBg.type = "image";
  proBg.image = "lyric_bg.png";
  proContainer.views.push(proBg);

  var progressView = new Object();
  progressView.id = common_id++;
  progressView.type = "inlineProgress";
  progressView.w = proContainer.w;
  progressView.h = proContainer.h;
  progressView.x = 0;
  progressView.y = 0;
  progressView.datasource = "progressBar";
  progressView.imageLeft = "";
  progressView.imageRight = "";
  progressView.imageLoad = "";
  progressView.imageThumb = "progress_thumb2@2x.png";
  proContainer.views.push(progressView);

  /* animation */
  var animId = 3000;
  player.animations = [];

  var slideOutAnim = new Object();
  slideOutAnim.id = animId++;
  slideOutAnim.type = "slideout";
  player.animations.push(slideOutAnim);

  /* trigger */
  var triggerid = 2000;
  player.triggers = [];

  var slideOut = new Object();
  slideOut.id = triggerid++;
  slideOut.action = "nextSong";
  slideOut.animations = [slideOutAnim.id];
  player.triggers.push(slideOut);

  /* hitarea */
  var hitareaId = 1000;
  player.hitarea = [];

  var albumSwipe = new Object();
  albumSwipe.id = hitareaId++;
  albumSwipe.viewId = lyricView.id;
  albumSwipe.x = 0;
  albumSwipe.y = 0;
  albumSwipe.w = lyricView.w;
  albumSwipe.h = lyricView.h;
  albumSwipe.gesture = "swipeLeft";
  albumSwipe.triggers = [slideOut.id];
  player.hitarea.push(albumSwipe);

  return JSON.stringify(player);
}

/*
var factorial = function(n) {
    if (n < 0)
        return;
    if (n === 0)
        return 1;
    return n * factorial(n - 1)
};
 */

document.addEventListener('DOMContentLoaded', function() {
  //alert("READY!");
  var json = viewJson(375, 667)
  document.getElementById("demo").innerHTML = json;
  createUI(json);
}, false);

